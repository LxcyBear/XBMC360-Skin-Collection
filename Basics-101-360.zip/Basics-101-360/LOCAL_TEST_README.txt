XBMC360 LOCAL SKIN PREVIEW: Basics-101-360

THIS IS A LOCAL-TEST PREVIEW, NOT A VERIFIED PRODUCTION PORT.
Tested: XML static parsing and extraction of the original Xbox XPR2 texture data.
Not tested: Xbox 360 GPU rendering, navigation, interactive behavior, packaging with XBMC360Tex.

1. Fonts are deliberately excluded from this archive.
   Basics: copy a font you are entitled to use (such as local Windows Arial.ttf) into this folder: fonts\Arial.ttf.
2. Extract this entire Basics-101-360 folder into your XBMC-360 application `skins` directory.
   XBMC360 application code uses D:\skins\ as the installed skin root.
3. Use the skin selector inside XBMC360 to switch skins.
4. The original Xbox XPR2 bundles are intentionally omitted: they are incompatible with the 360 XPR5 loader.
   Loose images are included under media\ and are expected to be loaded from files by XBMC360.
5. If menus look correct and performance is acceptable, repack to native XPR5 using XBMC360Tex.exe.
6. If the skin is black/blank, restore an existing working skin in settings.xml or by the UI fallback.

KNOWN LIMITATIONS
- XMBox: original bitmap fonts replaced by TTF descriptors; some unsupported controls and legacy actions may not work.
- Basics: original color theme packs have NOT been converted to 360 XPR5 yet. Default assets are supplied; themes stored separately as loose sources.
- Both: no 360 build or runtime test possible in this environment.

Converted XPR entries: {'Blue.xpr': 87, 'Gold.xpr': 87, 'Green.xpr': 87, 'Sepia.xpr': 89, 'textures.xpr': 138}
XML files repaired: []
Font descriptor files created: ['1080i/Fonts.xml', 'PAL16x9/Fonts.xml', '720p/Fonts.xml']
